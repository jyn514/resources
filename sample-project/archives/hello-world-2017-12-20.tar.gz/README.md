# Sample project

Project that shows off my fancy makefile.
