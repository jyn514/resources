mkdir -p ~/.archive ; n="$(date +"%Y-%m-%d_%H-%M-%S")_$(basename "$(pwd)")_backup.tar.gz" ; tar cvfz "$n" ./* ; mv "$n" ~/.archive
